/** Automatically generated file. DO NOT MODIFY */
package ilyag.ah42;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}