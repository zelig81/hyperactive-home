/** Automatically generated file. DO NOT MODIFY */
package ilyag.ah41;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}