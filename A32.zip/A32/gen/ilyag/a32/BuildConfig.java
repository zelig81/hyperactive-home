/** Automatically generated file. DO NOT MODIFY */
package ilyag.a32;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}