package project.ilyagorban.model.figures;

public interface MarkerRook {
	
}
