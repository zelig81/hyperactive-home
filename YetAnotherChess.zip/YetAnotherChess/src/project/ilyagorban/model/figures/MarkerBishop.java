package project.ilyagorban.model.figures;

public interface MarkerBishop {
	
}
