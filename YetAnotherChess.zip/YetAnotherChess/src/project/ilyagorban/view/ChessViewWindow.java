package project.ilyagorban.view;

import project.ilyagorban.model.figures.Figure;

public class ChessViewWindow implements Visualizable {
	
	@Override
	public String getInput(String string) {
		return null;
	}
	
	@Override
	public void getMessageToView(String string) {
		
	}
	
	@Override
	public void setMessage(String message) {
		
	}
	
	@Override
	public String showBoard(Figure[] figures, String currentOwner) {
		return null;
	}
	
}
