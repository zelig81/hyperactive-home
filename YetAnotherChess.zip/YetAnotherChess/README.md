Chess
=====

Yet another chess program (educational project)
